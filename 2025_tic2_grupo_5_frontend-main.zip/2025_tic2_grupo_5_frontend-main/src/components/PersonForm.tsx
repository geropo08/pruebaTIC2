"use client"

import type React from "react"
import { useState } from "react"
import { X } from "lucide-react"
import type { Person } from "../contexts/AppContext"
import { useApp } from "../contexts/AppContext"
import { useFormValidation } from "../hooks/useFormValidation"

interface PersonFormProps {
  person?: Person
  onClose: () => void
  onSubmit: (person: Person | Omit<Person, "id">) => void
  title: string
}

export function PersonForm({ person, onClose, onSubmit, title }: PersonFormProps) {
  const { companies } = useApp()
  const { errors, validateForm, setErrors } = useFormValidation()

  const [formData, setFormData] = useState({
    nombre: person?.nombre || "",
    apellido: person?.apellido || "",
    correo: person?.correo || "",
    fecha_nac: person?.fecha_nac || "",
    foto: person?.foto || "/placeholder.svg?height=150&width=150",
    puesto: person?.puesto || "",
    empresa_rut: person?.empresa_rut || "",
    tag_rfid: person?.tag_rfid || "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })

    // Clear error when typing
    if (errors[name]) {
      setErrors({ ...errors, [name]: "" })
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const validationRules = {
      nombre: { required: true },
      apellido: { required: true },
      correo: { required: true, isEmail: true },
      fecha_nac: { required: true, isDate: true },
      puesto: { required: true },
      empresa_rut: { required: true },
    }

    if (validateForm(formData, validationRules)) {
      if (person) {
        onSubmit({ ...person, ...formData })
      } else {
        onSubmit(formData)
      }
    }
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="close-button" onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="nombre">Nombre</label>
              <input
                id="nombre"
                name="nombre"
                type="text"
                value={formData.nombre}
                onChange={handleChange}
                placeholder="Nombre"
                className={errors.nombre ? "input-error" : ""}
              />
              {errors.nombre && <div className="error-message">{errors.nombre}</div>}
            </div>

            <div className="form-group">
              <label htmlFor="apellido">Apellido</label>
              <input
                id="apellido"
                name="apellido"
                type="text"
                value={formData.apellido}
                onChange={handleChange}
                placeholder="Apellido"
                className={errors.apellido ? "input-error" : ""}
              />
              {errors.apellido && <div className="error-message">{errors.apellido}</div>}
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="correo">Correo Electrónico</label>
            <input
              id="correo"
              name="correo"
              type="email"
              value={formData.correo}
              onChange={handleChange}
              placeholder="correo@ejemplo.com"
              className={errors.correo ? "input-error" : ""}
            />
            {errors.correo && <div className="error-message">{errors.correo}</div>}
          </div>

          <div className="form-group">
            <label htmlFor="fecha_nac">Fecha de Nacimiento</label>
            <input
              id="fecha_nac"
              name="fecha_nac"
              type="date"
              value={formData.fecha_nac}
              onChange={handleChange}
              className={errors.fecha_nac ? "input-error" : ""}
            />
            {errors.fecha_nac && <div className="error-message">{errors.fecha_nac}</div>}
          </div>

          <div className="form-group">
            <label htmlFor="foto">URL de Foto</label>
            <input
              id="foto"
              name="foto"
              type="text"
              value={formData.foto}
              onChange={handleChange}
              placeholder="URL de la foto"
            />
            <div className="photo-preview">
              <img src={formData.foto || "/placeholder.svg"} alt="Vista previa" />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="puesto">Puesto</label>
            <input
              id="puesto"
              name="puesto"
              type="text"
              value={formData.puesto}
              onChange={handleChange}
              placeholder="Puesto o cargo"
              className={errors.puesto ? "input-error" : ""}
            />
            {errors.puesto && <div className="error-message">{errors.puesto}</div>}
          </div>

          <div className="form-group">
            <label htmlFor="tag_rfid">Tag RFID</label>
            <input
              id="tag_rfid"
              name="tag_rfid"
              type="text"
              value={formData.tag_rfid}
              onChange={handleChange}
              placeholder="Código RFID asociado"
            />
          </div>

          <div className="form-group">
            <label htmlFor="empresa_rut">Empresa (RUT)</label>
            <select
              id="empresa_rut"
              name="empresa_rut"
              value={formData.empresa_rut}
              onChange={handleChange}
              className={errors.empresa_rut ? "input-error" : ""}
            >
              <option value="">Seleccione una empresa</option>
              {companies.map((company) => (
                <option key={company.rut} value={company.rut}>
                  {company.name} ({company.rut})
                </option>
              ))}
            </select>
            {errors.empresa_rut && <div className="error-message">{errors.empresa_rut}</div>}
          </div>

          <div className="form-actions">
            <button type="button" className="cancel-button" onClick={onClose}>
              Cancelar
            </button>
            <button type="submit" className="submit-button">
              {person ? "Actualizar" : "Agregar"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
