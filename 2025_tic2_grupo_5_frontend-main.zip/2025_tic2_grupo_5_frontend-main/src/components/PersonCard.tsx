"use client"

import type React from "react"

import { Edit, Trash2 } from "lucide-react"
import { Link } from "react-router-dom"
import type { Person } from "../contexts/AppContext"

interface PersonCardProps {
  person: Person
  onEdit?: (person: Person) => void
  onDelete?: (person: Person) => void
}

export function PersonCard({ person, onEdit, onDelete }: PersonCardProps) {
  const handleEditClick = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (onEdit) {
      onEdit(person)
    }
  }

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (onDelete) {
      onDelete(person)
    }
  }

  return (
    <div className="person-card-container">
      <Link to={`/personas/${person.id}`} className="person-card">
        <div className="person-avatar">
          <img src={person.foto || "/placeholder.svg"} alt={`${person.nombre} ${person.apellido}`} />
        </div>
        <div className="person-info">
          <h3>
            {person.nombre} {person.apellido}
          </h3>
          <p>{person.puesto}</p>
        </div>
      </Link>
      {(onEdit || onDelete) && (
        <div className="person-card-actions">
          {onEdit && (
            <button className="edit-button" onClick={handleEditClick}>
              <Edit size={18} />
            </button>
          )}
          {onDelete && (
            <button className="delete-button" onClick={handleDeleteClick}>
              <Trash2 size={18} />
            </button>
          )}
        </div>
      )}
    </div>
  )
}
