"use client"

import { ArrowLeft, Search, Trash2 } from "lucide-react"
import { useState, useEffect } from "react"
import { Link, useParams } from "react-router-dom"
import { useApp } from "../contexts/AppContext"
import { Header } from "./Header"
import { Breadcrumb } from "./Breadcrumb"
import { ConfirmDialog } from "./ConfirmDialog"

export function DoorDetail() {
  const { id } = useParams<{ id: string }>()
  const doorId = Number.parseInt(id || "0")
  const { getDoorById, persons, getCompanyByRut, setCurrentCompanyId } = useApp()
  const [searchPersons, setSearchPersons] = useState("")
  const [searchAllowed, setSearchAllowed] = useState("")

  // Para los confirm dialogs
  const [showAddConfirm, setShowAddConfirm] = useState(false)
  const [showRemoveConfirm, setShowRemoveConfirm] = useState(false)
  const [selectedPersonId, setSelectedPersonId] = useState<number | null>(null)

  // For demo purposes, we'll simulate allowed persons
  const [allowedPersons, setAllowedPersons] = useState<number[]>([1, 3])

  const door = getDoorById(doorId)

  // Determinar la empresa a la que pertenece esta puerta
  useEffect(() => {
    if (door && door.empresa_rut) {
      const company = getCompanyByRut(door.empresa_rut)
      if (company) {
        // Establecer la empresa actual para que aparezca en el breadcrumb
        setCurrentCompanyId(company.id)
      }
    }
  }, [door, getCompanyByRut, setCurrentCompanyId])

  if (!door) {
    return (
      <>
        <Header />
        <Breadcrumb />
        <div className="content-container">
          <div className="not-found">
            <h2>Puerta no encontrada</h2>
            <Link to="/puertas" className="back-link">
              <ArrowLeft size={16} />
              Volver a Puertas
            </Link>
          </div>
        </div>
      </>
    )
  }

  const filteredPersons = persons.filter(
    (person) =>
      !allowedPersons.includes(person.id) &&
      (`${person.nombre} ${person.apellido}`.toLowerCase().includes(searchPersons.toLowerCase()) ||
        person.puesto.toLowerCase().includes(searchPersons.toLowerCase())),
  )

  const filteredAllowedPersons = persons.filter(
    (person) =>
      allowedPersons.includes(person.id) &&
      (`${person.nombre} ${person.apellido}`.toLowerCase().includes(searchAllowed.toLowerCase()) ||
        person.puesto.toLowerCase().includes(searchAllowed.toLowerCase())),
  )

  const handleAddPersonClick = (personId: number) => {
    setSelectedPersonId(personId)
    setShowAddConfirm(true)
  }

  const handleRemovePersonClick = (personId: number) => {
    setSelectedPersonId(personId)
    setShowRemoveConfirm(true)
  }

  const addPersonAccess = () => {
    if (selectedPersonId && !allowedPersons.includes(selectedPersonId)) {
      setAllowedPersons([...allowedPersons, selectedPersonId])
    }
    setShowAddConfirm(false)
    setSelectedPersonId(null)
  }

  const removePersonAccess = () => {
    setAllowedPersons(allowedPersons.filter((id) => id !== selectedPersonId))
    setShowRemoveConfirm(false)
    setSelectedPersonId(null)
  }

  const getSelectedPersonName = () => {
    if (!selectedPersonId) return ""
    const person = persons.find((p) => p.id === selectedPersonId)
    return person ? `${person.nombre} ${person.apellido}` : ""
  }

  return (
    <>
      <Header />
      <Breadcrumb />
      <div className="content-container">
        <div className="door-detail">
          <div className="door-detail-header">
            <Link to="/puertas" className="back-link">
              <ArrowLeft size={16} />
              Volver a Puertas
            </Link>
            <h2>Nombre: {door.name}</h2>
            <p>Ubicación: {door.location}</p>
            <p>Dirección: {door.direccion || "No especificada"}</p>
            <p>Edificio: {door.edificio || "No especificado"}</p>
            <p>Salón: {door.salon || "No especificado"}</p>
            <p>Piso: {door.piso_ubicacion || "No especificado"}</p>
            <p>Fallos permitidos: {door.cantidad_de_fallos_permitidos || 0}</p>
          </div>
          <div className="door-access-management">
            <div className="access-section">
              <h3>Personas</h3>
              <div className="search-container">
                <input
                  type="text"
                  placeholder="Buscar"
                  value={searchPersons}
                  onChange={(e) => setSearchPersons(e.target.value)}
                />
                <Search size={16} className="search-icon" />
              </div>

              <div className="table-container">
                <table className="access-table">
                  <thead>
                    <tr>
                      <th>Identificador</th>
                      <th>Nombre</th>
                      <th>Puesto</th>
                      <th>Agregar</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredPersons.map((person) => (
                      <tr key={person.id}>
                        <td>{String(person.id).padStart(4, "0")}</td>
                        <td>
                          {person.nombre} {person.apellido}
                        </td>
                        <td>{person.puesto}</td>
                        <td>
                          <input type="checkbox" onChange={() => handleAddPersonClick(person.id)} />
                        </td>
                      </tr>
                    ))}
                    {filteredPersons.length === 0 && (
                      <tr>
                        <td colSpan={4} className="empty-table">
                          No hay personas disponibles
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="access-section">
              <h3>Lista Permitidos</h3>
              <div className="search-container">
                <input
                  type="text"
                  placeholder="Buscar"
                  value={searchAllowed}
                  onChange={(e) => setSearchAllowed(e.target.value)}
                />
                <Search size={16} className="search-icon" />
              </div>

              <div className="table-container">
                <table className="access-table">
                  <thead>
                    <tr>
                      <th>Identificador</th>
                      <th>Nombre</th>
                      <th>Puesto</th>
                      <th>Eliminar</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAllowedPersons.map((person) => (
                      <tr key={person.id}>
                        <td>{String(person.id).padStart(4, "0")}</td>
                        <td>
                          {person.nombre} {person.apellido}
                        </td>
                        <td>{person.puesto}</td>
                        <td>
                          <button className="delete-button" onClick={() => handleRemovePersonClick(person.id)}>
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {filteredAllowedPersons.length === 0 && (
                      <tr>
                        <td colSpan={4} className="empty-table">
                          No hay personas con acceso
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Confirm Dialog para agregar persona */}
      <ConfirmDialog
        isOpen={showAddConfirm}
        title="Agregar Acceso"
        message={`¿Está seguro que desea dar acceso a ${getSelectedPersonName()}?`}
        confirmText="Agregar"
        onConfirm={addPersonAccess}
        onCancel={() => {
          setShowAddConfirm(false)
          setSelectedPersonId(null)
        }}
        type="edit"
      />

      {/* Confirm Dialog para eliminar persona */}
      <ConfirmDialog
        isOpen={showRemoveConfirm}
        title="Eliminar Acceso"
        message={`¿Está seguro que desea eliminar el acceso de ${getSelectedPersonName()}?`}
        confirmText="Eliminar"
        onConfirm={removePersonAccess}
        onCancel={() => {
          setShowRemoveConfirm(false)
          setSelectedPersonId(null)
        }}
        type="delete"
      />
    </>
  )
}
