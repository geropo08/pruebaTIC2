import { CompanyCard } from "./CompanyCard"
import type { Company } from "../App"

interface CompanyGridProps {
  companies: Company[]
  onEdit: (company: Company) => void
  onDelete: (company: Company) => void
}

export function CompanyGrid({ companies, onEdit, onDelete }: CompanyGridProps) {
  return (
    <div className="company-grid">
      {companies.map((company) => (
        <CompanyCard key={company.id} company={company} onEdit={onEdit} onDelete={onDelete} />
      ))}
    </div>
  )
}
