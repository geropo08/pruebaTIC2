"use client"

import { ChevronRight, Home } from "lucide-react"
import { Link, useLocation, useParams } from "react-router-dom"
import { useApp } from "../contexts/AppContext"

export function Breadcrumb() {
  const location = useLocation()
  const params = useParams()
  const { getCompanyById, getDoorById, getPersonById, currentCompanyId, setCurrentCompanyId } = useApp()

  // Función para limpiar el contexto de empresa al hacer clic en inicio
  const handleHomeClick = () => {
    setCurrentCompanyId(null)
  }

  // Construir los elementos del breadcrumb
  const breadcrumbItems = []

  // Siempre agregamos el inicio
  breadcrumbItems.push({
    name: "Inicio",
    path: "/empresas",
    icon: <Home size={16} />,
  })

  // Si estamos en una vista de empresa específica
  if (params.id && location.pathname.startsWith("/empresas/")) {
    const companyId = Number.parseInt(params.id)
    const company = getCompanyById(companyId)
    if (company) {
      breadcrumbItems.push({
        name: company.name,
        path: `/empresas/${companyId}`,
        isLast: true,
      })
    }
  }
  // Si estamos en personas o puertas y hay una empresa seleccionada
  else if (currentCompanyId) {
    const company = getCompanyById(currentCompanyId)
    if (company) {
      breadcrumbItems.push({
        name: company.name,
        path: `/empresas/${currentCompanyId}`,
      })
    }

    // Agregar el segmento de sección (personas o puertas)
    if (location.pathname.startsWith("/personas")) {
      breadcrumbItems.push({
        name: "Personas",
        path: "/personas",
        isLast: !params.id,
      })

      // Si estamos en el detalle de una persona
      if (params.id) {
        const personId = Number.parseInt(params.id)
        const person = getPersonById(personId)
        if (person) {
          breadcrumbItems.push({
            name: `${person.nombre} ${person.apellido}`,
            path: `/personas/${personId}`,
            isLast: true,
          })
        }
      }
    } else if (location.pathname.startsWith("/puertas")) {
      breadcrumbItems.push({
        name: "Puertas",
        path: "/puertas",
        isLast: !params.id,
      })

      // Si estamos en el detalle de una puerta
      if (params.id) {
        const doorId = Number.parseInt(params.id)
        const door = getDoorById(doorId)
        if (door) {
          breadcrumbItems.push({
            name: door.name,
            path: `/puertas/${doorId}`,
            isLast: true,
          })
        }
      }
    }
  }
  // Si no hay empresa seleccionada pero estamos en personas o puertas
  else if (location.pathname.startsWith("/personas") || location.pathname.startsWith("/puertas")) {
    const section = location.pathname.startsWith("/personas") ? "Personas" : "Puertas"
    breadcrumbItems.push({
      name: section,
      path: location.pathname.split("/")[1],
      isLast: !params.id,
    })

    // Si estamos en el detalle de una persona o puerta
    if (params.id) {
      const id = Number.parseInt(params.id)
      if (location.pathname.startsWith("/personas")) {
        const person = getPersonById(id)
        if (person) {
          breadcrumbItems.push({
            name: `${person.nombre} ${person.apellido}`,
            path: `/personas/${id}`,
            isLast: true,
          })
        }
      } else if (location.pathname.startsWith("/puertas")) {
        const door = getDoorById(id)
        if (door) {
          breadcrumbItems.push({
            name: door.name,
            path: `/puertas/${id}`,
            isLast: true,
          })
        }
      }
    }
  }
  // Para otras rutas como cambio-contrasena
  else if (!location.pathname.startsWith("/empresas")) {
    const pathSegment = location.pathname.split("/")[1]
    let name = ""

    switch (pathSegment) {
      case "cambio-contrasena":
        name = "Cambio de Contraseña"
        break
      default:
        name = pathSegment.charAt(0).toUpperCase() + pathSegment.slice(1)
    }

    breadcrumbItems.push({
      name,
      path: `/${pathSegment}`,
      isLast: true,
    })
  }

  return (
    <div className="breadcrumb-container">
      <nav className="breadcrumb">
        <ol>
          {breadcrumbItems.map((item, index) => (
            <li key={index} className="breadcrumb-item">
              {item.isLast ? (
                <span className="breadcrumb-current">{item.name}</span>
              ) : (
                <>
                  <Link to={item.path} className="breadcrumb-link" onClick={index === 0 ? handleHomeClick : undefined}>
                    {item.icon || item.name}
                  </Link>
                  <ChevronRight size={14} className="breadcrumb-separator" />
                </>
              )}
            </li>
          ))}
        </ol>
      </nav>
    </div>
  )
}
