"use client"

import { ArrowLeft } from "lucide-react"
import { Link, useParams } from "react-router-dom"
import { useApp } from "../contexts/AppContext"
import { Header } from "./Header"
import { Breadcrumb } from "./Breadcrumb"
import { useEffect } from "react"

export function PersonDetail() {
  const { id } = useParams<{ id: string }>()
  const personId = Number.parseInt(id || "0")
  const { getPersonById, getCompanyByRut, setCurrentCompanyId } = useApp()

  const person = getPersonById(personId)

  // Determinar la empresa a la que pertenece esta persona
  useEffect(() => {
    if (person && person.empresa_rut) {
      const company = getCompanyByRut(person.empresa_rut)
      if (company) {
        // Establecer la empresa actual para que aparezca en el breadcrumb
        setCurrentCompanyId(company.id)
      }
    }
  }, [person, getCompanyByRut, setCurrentCompanyId])

  if (!person) {
    return (
      <>
        <Header />
        <Breadcrumb />
        <div className="content-container">
          <div className="not-found">
            <h2>Persona no encontrada</h2>
            <Link to="/personas" className="back-link">
              <ArrowLeft size={16} />
              Volver a Personas
            </Link>
          </div>
        </div>
      </>
    )
  }

  // Find the company this person belongs to
  const company = getCompanyByRut(person.empresa_rut)

  return (
    <>
      <Header />
      <Breadcrumb />
      <div className="content-container">
        <div className="person-detail">
          <div className="person-detail-header">
            <Link to="/personas" className="back-link">
              <ArrowLeft size={16} />
              Volver a Personas
            </Link>
            <h2>
              {person.nombre} {person.apellido}
            </h2>
          </div>

          <div className="person-detail-content">
            <div className="person-detail-photo">
              <img src={person.foto || "/placeholder.svg"} alt={`${person.nombre} ${person.apellido}`} />
            </div>

            <div className="person-detail-info">
              <div className="info-group">
                <h3>Información Personal</h3>

                <div className="info-row">
                  <div className="info-label">Nombre Completo</div>
                  <div className="info-value">
                    {person.nombre} {person.apellido}
                  </div>
                </div>

                <div className="info-row">
                  <div className="info-label">Correo Electrónico</div>
                  <div className="info-value">{person.correo}</div>
                </div>

                <div className="info-row">
                  <div className="info-label">Fecha de Nacimiento</div>
                  <div className="info-value">{new Date(person.fecha_nac).toLocaleDateString()}</div>
                </div>
              </div>

              <div className="info-group">
                <h3>Información Laboral</h3>

                <div className="info-row">
                  <div className="info-label">Puesto</div>
                  <div className="info-value">{person.puesto}</div>
                </div>

                <div className="info-row">
                  <div className="info-label">Empresa</div>
                  <div className="info-value">
                    {company ? <Link to={`/empresas/${company.id}`}>{company.name}</Link> : person.empresa_rut}
                  </div>
                </div>

                <div className="info-row">
                  <div className="info-label">RUT Empresa</div>
                  <div className="info-value">{person.empresa_rut}</div>
                </div>

                <div className="info-row">
                  <div className="info-label">Tag RFID</div>
                  <div className="info-value">{person.tag_rfid || "No asignado"}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
