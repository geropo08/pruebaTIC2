"use client"

import type React from "react"
import { useState } from "react"
import { X } from "lucide-react"
import type { Company } from "../contexts/AppContext"
import { useFormValidation } from "../hooks/useFormValidation"

interface CompanyFormProps {
  company?: Company
  onClose: () => void
  onSubmit: (company: Company | Omit<Company, "id">) => void
  title: string
}

export function CompanyForm({ company, onClose, onSubmit, title }: CompanyFormProps) {
  const [name, setName] = useState(company?.name || "")
  const [rut, setRut] = useState(company?.rut || "")
  const { errors, validateForm, setErrors } = useFormValidation()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const formData = { name, rut }
    const validationRules = {
      name: { required: true },
      rut: { required: true, isRut: true },
    }

    if (validateForm(formData, validationRules)) {
      if (company) {
        onSubmit({ ...company, name, rut })
      } else {
        onSubmit({ name, rut })
      }
    }
  }

  const formatRut = (value: string) => {
    let cleaned = value.replace(/[^\dkK]/g, "")

    if (cleaned.length > 1) {
      const verifier = cleaned.slice(-1)
      const numbers = cleaned.slice(0, -1)

      cleaned = `${numbers}-${verifier}`

      if (numbers.length > 3) {
        const thousands = numbers.slice(-3)
        const millions = numbers.slice(-6, -3)
        const billions = numbers.slice(0, -6)

        if (billions) {
          cleaned = `${billions}.${millions}.${thousands}-${verifier}`
        } else if (millions) {
          cleaned = `${millions}.${thousands}-${verifier}`
        }
      }
    }

    return cleaned
  }

  const handleRutChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatRut(e.target.value)
    setRut(formatted)

    // Clear error when typing
    if (errors.rut) {
      setErrors({ ...errors, rut: "" })
    }
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="close-button" onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="rut">RUT</label>
            <input
              id="rut"
              type="text"
              value={rut}
              onChange={handleRutChange}
              placeholder="Ej: 76.123.456-7"
              className={errors.rut ? "input-error" : ""}
            />
            {errors.rut && <div className="error-message">{errors.rut}</div>}
          </div>

          <div className="form-group">
            <label htmlFor="name">Nombre de Empresa</label>
            <input
              id="name"
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value)
                if (errors.name) {
                  setErrors({ ...errors, name: "" })
                }
              }}
              placeholder="Nombre de la empresa"
              className={errors.name ? "input-error" : ""}
            />
            {errors.name && <div className="error-message">{errors.name}</div>}
          </div>

          <div className="form-actions">
            <button type="button" className="cancel-button" onClick={onClose}>
              Cancelar
            </button>
            <button type="submit" className="submit-button">
              {company ? "Actualizar" : "Agregar"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
