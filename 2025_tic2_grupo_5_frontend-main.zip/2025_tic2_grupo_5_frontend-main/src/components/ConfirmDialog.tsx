"use client"

import { X } from "lucide-react"

interface ConfirmDialogProps {
  isOpen: boolean
  title: string
  message: string
  confirmText?: string
  cancelText?: string
  onConfirm: () => void
  onCancel: () => void
  type?: "delete" | "edit" | "default"
}

export function ConfirmDialog({
  isOpen,
  title,
  message,
  confirmText = "Confirmar",
  cancelText = "Cancelar",
  onConfirm,
  onCancel,
  type = "default",
}: ConfirmDialogProps) {
  if (!isOpen) return null

  const getHeaderClass = () => {
    switch (type) {
      case "delete":
        return "bg-red-600"
      case "edit":
        return "bg-green-600" 
      default:
        return "bg-green-600" 
    }
  }

  const getConfirmButtonClass = () => {
    switch (type) {
      case "delete":
        return "bg-red-600 hover:bg-red-700"
      case "edit":
        return "bg-green-600 hover:bg-green-700" 
      default:
        return "bg-green-600 hover:bg-green-700" 
    }
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content" style={{ maxWidth: "400px" }}>
        <div className={`modal-header ${getHeaderClass()}`}>
          <h2>{title}</h2>
          <button className="close-button" onClick={onCancel}>
            <X size={20} />
          </button>
        </div>
        <div className="p-5">
          <p className="mb-6 text-center">{message}</p>
          <div className="flex justify-center gap-4">
            <button className="cancel-button" onClick={onCancel}>
              {cancelText}
            </button>
            <button className={`submit-button ${getConfirmButtonClass()}`} onClick={onConfirm}>
              {confirmText}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
