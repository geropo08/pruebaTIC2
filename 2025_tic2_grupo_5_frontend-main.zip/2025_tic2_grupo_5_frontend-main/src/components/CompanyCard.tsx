"use client"

import { Edit, Trash2 } from "lucide-react"
import { Link } from "react-router-dom"
import type { Company } from "../contexts/AppContext"

interface CompanyCardProps {
  company: Company
  onEdit: (company: Company) => void
  onDelete: (company: Company) => void
}

export function CompanyCard({ company, onEdit, onDelete }: CompanyCardProps) {
  return (
    <div className="company-card">
      <div className="company-id">{company.id}</div>
      <Link to={`/empresas/${company.id}`} className="company-name">
        {company.name}
      </Link>
      <div className="card-actions">
        <button className="edit-button" onClick={() => onEdit(company)}>
          <Edit size={18} />
        </button>
        <button className="delete-button" onClick={() => onDelete(company)}>
          <Trash2 size={18} />
        </button>
      </div>
    </div>
  )
}
