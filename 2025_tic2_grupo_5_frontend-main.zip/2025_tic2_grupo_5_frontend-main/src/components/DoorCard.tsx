"use client"

import type React from "react"

import { Edit, Trash2 } from "lucide-react"
import { useNavigate } from "react-router-dom"
import type { Door } from "../contexts/AppContext"

interface DoorCardProps {
  door: Door
  onEdit?: (door: Door) => void
  onDelete?: (door: Door) => void
}

export function DoorCard({ door, onEdit, onDelete }: DoorCardProps) {
  const navigate = useNavigate()

  const handleCardClick = () => {
    navigate(`/puertas/${door.id}`)
  }

  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (onEdit) {
      onEdit(door)
    }
  }

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (onDelete) {
      onDelete(door)
    }
  }

  return (
    <div className="door-card" onClick={handleCardClick}>
      <div className="door-info">
        <h3>{door.name}</h3>
        <p>{door.location}</p>
      </div>
      <div className="door-card-actions">
        {onEdit && (
          <button className="edit-button" onClick={handleEditClick}>
            <Edit size={18} />
          </button>
        )}
        {onDelete && (
          <button className="delete-button" onClick={handleDeleteClick}>
            <Trash2 size={18} />
          </button>
        )}
      </div>
    </div>
  )
}
