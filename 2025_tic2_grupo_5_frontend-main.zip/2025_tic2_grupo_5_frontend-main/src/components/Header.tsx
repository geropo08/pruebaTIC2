"use client"

import { useLocation, useParams } from "react-router-dom"
import { useApp } from "../contexts/AppContext"

export function Header() {
  const location = useLocation()
  const params = useParams()
  const { getCompanyById, currentCompanyId, getCompanyByRut, persons, doors } = useApp()

  // Determinar si estamos en la página de inicio (vista de empresas)
  const isHomePage = location.pathname === "/empresas" || location.pathname === "/"

  if (isHomePage) {
    return (
      <header className="header">
        <div className="user-info">
          <span className="user-name">Usuario</span>
        </div>
      </header>
    )
  }

  let company = null

  // Caso 1: Estamos en la vista de detalle de una empresa
  const companyIdFromParams = params.id ? Number.parseInt(params.id) : null
  if (companyIdFromParams) {
    company = getCompanyById(companyIdFromParams)
  }
  // Caso 2: Tenemos una empresa seleccionada en el contexto global
  else if (currentCompanyId) {
    company = getCompanyById(currentCompanyId)
  }
  // Caso 3: Estamos en la vista de detalle de una persona
  else if (location.pathname.includes("/personas/") && params.id) {
    const personId = Number.parseInt(params.id)
    const person = persons.find((p) => p.id === personId)
    if (person) {
      company = getCompanyByRut(person.empresa_rut)
    }
  }
  // Caso 4: Estamos en la vista de detalle de una puerta
  else if (location.pathname.includes("/puertas/") && params.id) {
    const doorId = Number.parseInt(params.id)
    const door = doors.find((d) => d.id === doorId)
    if (door && door.empresa_rut) {
      company = getCompanyByRut(door.empresa_rut)
    }
  }

  return (
    <header className="header">
      <div className="user-info">
        <span className="user-name">Usuario</span>
        {company && <span className="company-indicator">| {company.name}</span>}
      </div>
    </header>
  )
}
