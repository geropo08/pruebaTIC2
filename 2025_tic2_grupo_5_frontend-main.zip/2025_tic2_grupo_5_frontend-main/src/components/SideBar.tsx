"use client"

import { Home, Key, LogOut, Menu } from "lucide-react"
import { Link, useLocation, useNavigate, useParams } from "react-router-dom"
import { useAuth } from "../contexts/AuthContext"
import { useApp } from "../contexts/AppContext"
import { useEffect, useState } from "react"
import { ConfirmDialog } from "./ConfirmDialog" // Add this import

interface SidebarProps {
  collapsed: boolean
  toggleSidebar: () => void
}

export function Sidebar({ collapsed, toggleSidebar }: SidebarProps) {
  const location = useLocation()
  const navigate = useNavigate()
  const { logout } = useAuth()
  const { getCompanyById } = useApp()
  const params = useParams()
  const [currentCompany, setCurrentCompany] = useState<{ id: number; name: string } | null>(null)
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false) // Add this state

  // Determinar si estamos dentro de una empresa específica
  useEffect(() => {
    const companyId = params.id ? Number.parseInt(params.id) : null
    if (companyId) {
      const company = getCompanyById(companyId)
      if (company) {
        setCurrentCompany({ id: company.id, name: company.name })
      } else {
        setCurrentCompany(null)
      }
    } else {
      setCurrentCompany(null)
    }
  }, [params.id, getCompanyById])

  // Update the handleLogout function to show the confirmation dialog
  const handleLogout = () => {
    setShowLogoutConfirm(true)
  }

  // Add these new handler functions
  const handleLogoutConfirm = () => {
    logout()
    navigate("/login")
    setShowLogoutConfirm(false)
  }

  const handleLogoutCancel = () => {
    setShowLogoutConfirm(false)
  }

  return (
    <>
      <aside className={`sidebar ${collapsed ? "collapsed" : ""}`}>
        <button className="hamburger-button" onClick={toggleSidebar}>
          <Menu size={16} />
        </button>

        <div className="user-profile">
          <div className="avatar">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="8" r="5" />
              <path d="M20 21a8 8 0 0 0-16 0" />
            </svg>
          </div>
          <span>Usuario</span>
        </div>

        {currentCompany && (
          <div className="current-company">
            <span>Empresa: {currentCompany.name}</span>
          </div>
        )}

        <nav className="nav-menu">
          <>
            <Link to="/empresas" className={`nav-item ${location.pathname === "/empresas" ? "active" : ""}`}>
              <Home size={20} />
              <span>Inicio</span>
            </Link>
          </>
          <Link
            to="/cambio-contrasena"
            className={`nav-item ${location.pathname.includes("/cambio-contrasena") ? "active" : ""}`}
          >
            <Key size={20} />
            <span>Cambio Contraseña</span>
          </Link>
        </nav>

        <button className="logout-button" onClick={handleLogout}>
          <LogOut size={18} />
          <span>Cerrar Sesion</span>
        </button>
      </aside>

      {/* Add the confirmation dialog */}
      <ConfirmDialog
        isOpen={showLogoutConfirm}
        title="Cerrar Sesión"
        message="¿Está seguro que desea cerrar la sesión?"
        confirmText="Cerrar Sesión"
        cancelText="Cancelar"
        onConfirm={handleLogoutConfirm}
        onCancel={handleLogoutCancel}
        type="delete"
      />
    </>
  )
}
