"use client"

import type React from "react"
import { useState } from "react"
import { X } from 'lucide-react'
import type { Door } from "../contexts/AppContext"
import { useApp } from "../contexts/AppContext"
import { useFormValidation } from "../hooks/useFormValidation"

interface DoorFormProps {
  door?: Door
  onClose: () => void
  onSubmit: (door: Door | Omit<Door, "id">) => void
  title: string
}

export function DoorForm({ door, onClose, onSubmit, title }: DoorFormProps) {
  const { companies } = useApp()
  const { errors, validateForm, setErrors } = useFormValidation()

  const [formData, setFormData] = useState({
    name: door?.name || "",
    location: door?.location || "",
    direccion: door?.direccion || "",
    edificio: door?.edificio || "",
    salon: door?.salon || "",
    piso_ubicacion: door?.piso_ubicacion || "",
    cantidad_de_fallos_permitidos: door?.cantidad_de_fallos_permitidos?.toString() || "3",
    empresa_rut: door?.empresa_rut || "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })

    // Clear error when typing
    if (errors[name]) {
      setErrors({ ...errors, [name]: "" })
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const validationRules = {
      name: { required: true },
      location: { required: true },
      direccion: { required: true },
      edificio: { required: true },
      salon: { required: true },
      piso_ubicacion: { required: true },
      cantidad_de_fallos_permitidos: { required: true },
      empresa_rut: { required: true },
    }

    if (validateForm(formData, validationRules)) {
      const doorData = {
        ...formData,
        cantidad_de_fallos_permitidos: parseInt(formData.cantidad_de_fallos_permitidos, 10),
      }

      if (door) {
        onSubmit({ ...door, ...doorData })
      } else {
        onSubmit(doorData)
      }
    }
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="close-button" onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="name">Nombre de la Puerta</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              placeholder="Ej: Puerta Principal"
              className={errors.name ? "input-error" : ""}
            />
            {errors.name && <div className="error-message">{errors.name}</div>}
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="location">Ubicación</label>
              <input
                id="location"
                name="location"
                type="text"
                value={formData.location}
                onChange={handleChange}
                placeholder="Ej: Entrada"
                className={errors.location ? "input-error" : ""}
              />
              {errors.location && <div className="error-message">{errors.location}</div>}
            </div>

          </div>

          <div className="form-group">
            <label htmlFor="direccion">Dirección</label>
            <input
              id="direccion"
              name="direccion"
              type="text"
              value={formData.direccion}
              onChange={handleChange}
              placeholder="Ej: Av. Principal 123"
              className={errors.direccion ? "input-error" : ""}
            />
            {errors.direccion && <div className="error-message">{errors.direccion}</div>}
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="edificio">Edificio</label>
              <input
                id="edificio"
                name="edificio"
                type="text"
                value={formData.edificio}
                onChange={handleChange}
                placeholder="Ej: Edificio Central"
                className={errors.edificio ? "input-error" : ""}
              />
              {errors.edificio && <div className="error-message">{errors.edificio}</div>}
            </div>

            <div className="form-group">
              <label htmlFor="salon">Salón</label>
              <input
                id="salon"
                name="salon"
                type="text"
                value={formData.salon}
                onChange={handleChange}
                placeholder="Ej: Oficina 101"
                className={errors.salon ? "input-error" : ""}
              />
              {errors.salon && <div className="error-message">{errors.salon}</div>}
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="piso_ubicacion">Piso</label>
              <input
                id="piso_ubicacion"
                name="piso_ubicacion"
                type="text"
                value={formData.piso_ubicacion}
                onChange={handleChange}
                placeholder="Ej: 1"
                className={errors.piso_ubicacion ? "input-error" : ""}
              />
              {errors.piso_ubicacion && <div className="error-message">{errors.piso_ubicacion}</div>}
            </div>

            <div className="form-group">
              <label htmlFor="cantidad_de_fallos_permitidos">Fallos Permitidos</label>
              <input
                id="cantidad_de_fallos_permitidos"
                name="cantidad_de_fallos_permitidos"
                type="number"
                min="0"
                value={formData.cantidad_de_fallos_permitidos}
                onChange={handleChange}
                placeholder="Ej: 3"
                className={errors.cantidad_de_fallos_permitidos ? "input-error" : ""}
              />
              {errors.cantidad_de_fallos_permitidos && (
                <div className="error-message">{errors.cantidad_de_fallos_permitidos}</div>
              )}
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="empresa_rut">Empresa (RUT)</label>
            <select
              id="empresa_rut"
              name="empresa_rut"
              value={formData.empresa_rut}
              onChange={handleChange}
              className={errors.empresa_rut ? "input-error" : ""}
            >
              <option value="">Seleccione una empresa</option>
              {companies.map((company) => (
                <option key={company.rut} value={company.rut}>
                  {company.name} ({company.rut})
                </option>
              ))}
            </select>
            {errors.empresa_rut && <div className="error-message">{errors.empresa_rut}</div>}
          </div>

          <div className="form-actions">
            <button type="button" className="cancel-button" onClick={onClose}>
              Cancelar
            </button>
            <button type="submit" className="submit-button">
              {door ? "Actualizar" : "Agregar"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
