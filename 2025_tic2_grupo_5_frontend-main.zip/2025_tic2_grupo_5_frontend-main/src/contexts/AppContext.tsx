"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

// Types
export interface Company {
  id: number
  name: string
  rut: string
}

export interface Person {
  id: number
  nombre: string
  apellido: string
  correo: string
  fecha_nac: string
  foto: string
  puesto: string
  empresa_rut: string
  tag_rfid?: string 
}

export interface Door {
  id: number
  name: string
  location: string
  direccion?: string
  edificio?: string
  salon?: string
  piso_ubicacion?: string
  cantidad_de_fallos_permitidos?: number
  empresa_rut?: string
}

interface AppContextType {
  companies: Company[]
  persons: Person[]
  doors: Door[]
  currentCompanyId: number | null
  setCurrentCompanyId: (id: number | null) => void
  addCompany: (company: Omit<Company, "id">) => void
  updateCompany: (company: Company) => void
  deleteCompany: (id: number) => void
  addPerson: (person: Omit<Person, "id">) => void
  updatePerson: (person: Person) => void
  deletePerson: (id: number) => void
  addDoor: (door: Omit<Door, "id">) => void
  updateDoor: (door: Door) => void
  deleteDoor: (id: number) => void
  getCompanyById: (id: number) => Company | undefined
  getPersonById: (id: number) => Person | undefined
  getDoorById: (id: number) => Door | undefined
  getCompanyByRut: (rut: string) => Company | undefined
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: ReactNode }) {
  const [companies, setCompanies] = useState<Company[]>([
    { id: 1, name: "Empresa 1", rut: "76.111.222-3" },
    { id: 2, name: "Empresa 2", rut: "76.123.456-7" },
    { id: 3, name: "Empresa 3", rut: "76.234.567-8" },
    { id: 5, name: "Empresa 5", rut: "76.345.678-9" },
    { id: 6, name: "Empresa 6", rut: "76.456.789-0" },
  ])

  const [persons, setPersons] = useState<Person[]>([
    {
      id: 1,
      nombre: "Juan",
      apellido: "Pérez",
      correo: "juan.perez@empresa1.com",
      fecha_nac: "1985-05-15",
      foto: "/placeholder.svg?height=150&width=150",
      puesto: "Gerente",
      empresa_rut: "76.111.222-3",
      tag_rfid: "A1B2C3D4",
    },
    {
      id: 2,
      nombre: "María",
      apellido: "González",
      correo: "maria.gonzalez@empresa2.com",
      fecha_nac: "1990-10-20",
      foto: "/placeholder.svg?height=150&width=150",
      puesto: "Desarrollador",
      empresa_rut: "76.123.456-7",
      tag_rfid: "E5F6G7H8",
    },
    {
      id: 3,
      nombre: "Carlos",
      apellido: "Rodríguez",
      correo: "carlos.rodriguez@empresa3.com",
      fecha_nac: "1988-03-25",
      foto: "/placeholder.svg?height=150&width=150",
      puesto: "Analista",
      empresa_rut: "76.234.567-8",
      tag_rfid: "I9J0K1L2",
    },
  ])

  const [doors, setDoors] = useState<Door[]>([
    {
      id: 1,
      name: "Puerta Principal",
      location: "Entrada",
      empresa_rut: "76.111.222-3",
    },
    {
      id: 2,
      name: "Puerta Oficina 101",
      location: "Piso 1",
      empresa_rut: "76.123.456-7",
    },
    {
      id: 3,
      name: "Puerta Sala Reuniones",
      location: "Piso 2",
      empresa_rut: "76.234.567-8",
    },
    {
      id: 4,
      name: "Puerta Emergencia",
      location: "Lateral",
      empresa_rut: "76.345.678-9",
    },
  ])

  // Estado para mantener la empresa actual seleccionada
  const [currentCompanyId, setCurrentCompanyId] = useState<number | null>(null)

  const addCompany = (company: Omit<Company, "id">) => {
    const newId = Math.max(0, ...companies.map((c) => c.id)) + 1
    setCompanies([...companies, { ...company, id: newId }])
  }

  const updateCompany = (updatedCompany: Company) => {
    setCompanies(companies.map((company) => (company.id === updatedCompany.id ? updatedCompany : company)))
  }

  const deleteCompany = (id: number) => {
    setCompanies(companies.filter((company) => company.id !== id))
  }

  const addPerson = (person: Omit<Person, "id">) => {
    const newId = Math.max(0, ...persons.map((p) => p.id)) + 1
    setPersons([...persons, { ...person, id: newId }])
  }

  const updatePerson = (updatedPerson: Person) => {
    setPersons(persons.map((person) => (person.id === updatedPerson.id ? updatedPerson : person)))
  }

  const deletePerson = (id: number) => {
    setPersons(persons.filter((person) => person.id !== id))
  }

  const addDoor = (door: Omit<Door, "id">) => {
    const newId = Math.max(0, ...doors.map((d) => d.id)) + 1
    setDoors([...doors, { ...door, id: newId }])
  }

  const updateDoor = (updatedDoor: Door) => {
    setDoors(doors.map((door) => (door.id === updatedDoor.id ? updatedDoor : door)))
  }

  const deleteDoor = (id: number) => {
    setDoors(doors.filter((door) => door.id !== id))
  }

  const getCompanyById = (id: number) => {
    return companies.find((company) => company.id === id)
  }

  const getPersonById = (id: number) => {
    return persons.find((person) => person.id === id)
  }

  const getDoorById = (id: number) => {
    return doors.find((door) => door.id === id)
  }

  const getCompanyByRut = (rut: string) => {
    return companies.find((company) => company.rut === rut)
  }

  return (
    <AppContext.Provider
      value={{
        companies,
        persons,
        doors,
        currentCompanyId,
        setCurrentCompanyId,
        addCompany,
        updateCompany,
        deleteCompany,
        addPerson,
        updatePerson,
        deletePerson,
        addDoor,
        updateDoor,
        deleteDoor,
        getCompanyById,
        getPersonById,
        getDoorById,
        getCompanyByRut,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider")
  }
  return context
}
