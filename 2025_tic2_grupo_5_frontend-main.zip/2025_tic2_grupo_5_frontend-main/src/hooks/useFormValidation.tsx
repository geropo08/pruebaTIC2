"use client"

import { useState } from "react"

interface ValidationRules {
  required?: boolean
  minLength?: number
  maxLength?: number
  pattern?: RegExp
  isEmail?: boolean
  isDate?: boolean
  isRut?: boolean
  custom?: (value: string) => boolean
}

interface ValidationErrors {
  [key: string]: string
}

export function useFormValidation() {
  const [errors, setErrors] = useState<ValidationErrors>({})

  const validateField = (name: string, value: string, rules: ValidationRules): string => {
    if (rules.required && !value.trim()) {
      return "Este campo es requerido"
    }

    if (rules.minLength && value.length < rules.minLength) {
      return `Debe tener al menos ${rules.minLength} caracteres`
    }

    if (rules.maxLength && value.length > rules.maxLength) {
      return `Debe tener máximo ${rules.maxLength} caracteres`
    }

    if (rules.pattern && !rules.pattern.test(value)) {
      return "Formato inválido"
    }

    if (rules.isEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      return "Correo electrónico inválido"
    }

    if (rules.isDate) {
      const date = new Date(value)
      if (isNaN(date.getTime())) {
        return "Fecha inválida"
      }
    }

    if (rules.isRut && !validateRut(value)) {
      return "RUT inválido"
    }

    if (rules.custom && !rules.custom(value)) {
      return "Valor inválido"
    }

    if (rules.required && !value.trim()) {
      return `El campo "${name}" es obligatorio`
    }    

    return ""
  }

  const validateForm = (
    formData: { [key: string]: string },
    validationRules: { [key: string]: ValidationRules },
  ): boolean => {
    const newErrors: ValidationErrors = {}
    let isValid = true

    Object.keys(validationRules).forEach((fieldName) => {
      const value = formData[fieldName] || ""
      const error = validateField(fieldName, value, validationRules[fieldName])

      if (error) {
        newErrors[fieldName] = error
        isValid = false
      }
    })

    setErrors(newErrors)
    return isValid
  }

  const validateRut = (rut: string): boolean => {
    // Formao: XX.XXX.XXX-X or XXXXXXXX-X
    const rutRegex = /^(\d{1,3}(\.\d{3}){2}-[\dkK])|(\d{7,8}-[\dkK])$/
    return rutRegex.test(rut)
  }

  return {
    errors,
    validateForm,
    validateField,
    setErrors,
  }
}
