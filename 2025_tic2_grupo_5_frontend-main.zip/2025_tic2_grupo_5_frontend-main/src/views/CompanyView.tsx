"use client"

import { useState } from "react"
import { Header } from "../components/Header"
import { CompanyCard } from "../components/CompanyCard"
import { CompanyForm } from "../components/CompanyForm"
import { ConfirmDialog } from "../components/ConfirmDialog"
import { useApp } from "../contexts/AppContext"
import { useModal } from "../hooks/useModal"
import { Breadcrumb } from "../components/Breadcrumb"
import { Building } from "lucide-react"
import { SearchBar } from "../components/SearchBar"
import type { Company } from "../App"


export function CompanyView() {
  const { companies, addCompany, updateCompany, deleteCompany } = useApp()
  const { isOpen: showAddForm, openModal: openAddForm, closeModal: closeAddForm } = useModal()
  const [editingCompany, setEditingCompany] = useState<(typeof companies)[0] | null>(null)
  const [pendingEditCompany, setPendingEditCompany] = useState<(typeof companies)[0] | null>(null)
  const [deletingCompany, setDeletingCompany] = useState<(typeof companies)[0] | null>(null)
  const [showEditConfirm, setShowEditConfirm] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  const handleAddCompany = (company: Omit<(typeof companies)[0], "id">) => {
    addCompany(company)
    closeAddForm()
  }

  const handleEditClick = (company: (typeof companies)[0]) => {
    setEditingCompany(company)
  }

  const handleEditCompany = (updatedCompany: Company | Omit<Company, "id">) => {
    if ("id" in updatedCompany) {
      setEditingCompany(null)
      setPendingEditCompany(updatedCompany)
      setShowEditConfirm(true)
    }
  }

  const handleEditConfirm = () => {
    if (pendingEditCompany) {
      updateCompany(pendingEditCompany)
      setPendingEditCompany(null)
    }
    setShowEditConfirm(false)
  }

  const handleEditCancel = () => {
    setPendingEditCompany(null)
    setShowEditConfirm(false)
  }

  const handleDeleteClick = (company: (typeof companies)[0]) => {
    setDeletingCompany(company)
    setShowDeleteConfirm(true)
  }

  const handleDeleteConfirm = () => {
    if (deletingCompany) {
      deleteCompany(deletingCompany.id)
      setShowDeleteConfirm(false)
      setDeletingCompany(null)
    }
  }

  const handleDeleteCancel = () => {
    setShowDeleteConfirm(false)
    setDeletingCompany(null)
  }

  const [searchTerm, setSearchTerm] = useState("")
  const finalCompanies = companies.filter((c) => c.name.toLowerCase().includes(searchTerm.toLowerCase()))

  return (
    <>
      <Header />
      <Breadcrumb />
      <div className="content-container">
        <div className="add-company-container">
          <button className="add-company-button" onClick={openAddForm}>
            Agregar Empresa
          </button>
        </div>

        <SearchBar placeholder="Buscar empresas..." value={searchTerm} onChange={setSearchTerm} />

        {companies.length > 0 ? (
          <div className="company-grid">
            {finalCompanies.map((company) => (
              <CompanyCard key={company.id} company={company} onEdit={handleEditClick} onDelete={handleDeleteClick} />
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <Building size={48} className="empty-state-icon" />
            <h3>No hay empresas</h3>
            <p>Haga clic en "Agregar Empresa" para crear una nueva empresa.</p>
          </div>
        )}
      </div>

      {showAddForm && <CompanyForm onClose={closeAddForm} onSubmit={handleAddCompany} title="Agregar Empresa" />}

      {showEditConfirm && (
        <ConfirmDialog
          isOpen={true}
          title="Editar Empresa"
          message={`¿Está seguro que desea editar la empresa ${pendingEditCompany?.name}?`}
          confirmText="Editar"
          onConfirm={handleEditConfirm}
          onCancel={handleEditCancel}
          type="edit"
        />
      )}

      {editingCompany && (
        <CompanyForm
          company={editingCompany}
          onClose={() => setEditingCompany(null)}
          onSubmit={handleEditCompany}
          title="Editar Empresa"
        />
      )}

      <ConfirmDialog
        isOpen={showDeleteConfirm}
        title="Eliminar Empresa"
        message={`¿Está seguro que desea eliminar la empresa ${deletingCompany?.name}?`}
        confirmText="Eliminar"
        onConfirm={handleDeleteConfirm}
        onCancel={handleDeleteCancel}
        type="delete"
      />
    </>
  )
}
