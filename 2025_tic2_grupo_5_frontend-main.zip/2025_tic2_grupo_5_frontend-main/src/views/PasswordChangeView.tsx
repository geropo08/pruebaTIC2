"use client"

import type React from "react"

import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { Header } from "../components/Header"
import { Breadcrumb } from "../components/Breadcrumb"
import "../styles/PasswordChange.css"

export function PasswordChangeView() {
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState("")
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const navigate = useNavigate()

  const validateForm = () => {
    if (!currentPassword) {
      setError("Por favor ingrese su contraseña actual")
      return false
    }
    if (!newPassword) {
      setError("Por favor ingrese su nueva contraseña")
      return false
    }
    if (newPassword !== confirmPassword) {
      setError("Las contraseñas nuevas no coinciden")
      return false
    }
    if (newPassword.length < 6) {
      setError("La contraseña debe tener al menos 6 caracteres")
      return false
    }
    return true
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (validateForm()) {
      setShowConfirmDialog(true)
    }
  }

  const handleConfirm = () => {
    alert("Contraseña cambiada exitosamente")
    navigate("/empresas")
  }

  const handleCancel = () => {
    setShowConfirmDialog(false)
  }

  return (
    <>
      <Header />
      <div className="content-container">
        <Breadcrumb />

        <div className="password-change-container">
          <div className="password-change-card">
            <div className="password-change-header">
              <h2>Cambio de Contraseña</h2>
            </div>

            <form onSubmit={handleSubmit} className="password-change-form">
              {error && <div className="password-error">{error}</div>}

              <div className="password-field">
                <label htmlFor="current-password">Contraseña Actual</label>
                <input
                  id="current-password"
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                />
              </div>

              <div className="password-field">
                <label htmlFor="new-password">Contraseña Nueva</label>
                <input
                  id="new-password"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
              </div>

              <div className="password-field">
                <label htmlFor="confirm-password">Repita Contraseña Nueva</label>
                <input
                  id="confirm-password"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
              </div>

              <div className="password-actions">
                <button type="submit" className="password-confirm-button">
                  Confirmar
                </button>
              </div>
            </form>
          </div>
        </div>

        {showConfirmDialog && (
          <div className="confirm-dialog-overlay">
            <div className="confirm-dialog">
              <div className="confirm-dialog-header">
                <h3>Confirmar</h3>
              </div>
              <div className="confirm-dialog-content">
                <p>¿Estas seguro que deseas cambiar la contraseña?</p>
                <div className="confirm-dialog-actions">
                  <button className="cancel-button" onClick={handleCancel}>
                    Cancelar
                  </button>
                  <button className="confirm-button" onClick={handleConfirm}>
                    Confirmar
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  )
}
