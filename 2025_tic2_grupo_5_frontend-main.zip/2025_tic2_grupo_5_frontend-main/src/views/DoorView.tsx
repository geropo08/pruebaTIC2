"use client"

import { useState} from "react"
import { Header } from "../components/Header"
import { DoorCard } from "../components/DoorCard"
import { DoorForm } from "../components/DoorForm"
import { ConfirmDialog } from "../components/ConfirmDialog"
import { useApp } from "../contexts/AppContext"
import { useModal } from "../hooks/useModal"
import { Breadcrumb } from "../components/Breadcrumb"
import { SearchBar } from "../components/SearchBar"
import { DoorOpen } from "lucide-react"
import type { Door } from "../contexts/AppContext"

export function DoorView() {
  const { doors, addDoor, updateDoor, deleteDoor, currentCompanyId, getCompanyById } = useApp()
  const { isOpen: showAddForm, openModal: openAddForm, closeModal: closeAddForm } = useModal()
  const [editingDoor, setEditingDoor] = useState<(typeof doors)[0] | null>(null)
  const [pendingEditDoor, setPendingEditDoor] = useState<(typeof doors)[0] | null>(null)
  const [deletingDoor, setDeletingDoor] = useState<(typeof doors)[0] | null>(null)
  const [showEditConfirm, setShowEditConfirm] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)


  const handleAddDoor = (door: Omit<(typeof doors)[0], "id">) => {
    addDoor(door)
    closeAddForm()
  }

  const handleEditClick = (door: (typeof doors)[0]) => {
    setEditingDoor(door)
  }

  const handleEditDoor = (updatedDoor: Door | Omit<Door, "id">) => {
    setEditingDoor(null)
  
    if ("id" in updatedDoor) {
      setPendingEditDoor(updatedDoor)
      setShowEditConfirm(true)
    }
  }
  

  const handleEditConfirm = () => {
    if (pendingEditDoor) {
      updateDoor(pendingEditDoor)
      setPendingEditDoor(null)
    }
    setShowEditConfirm(false)
  }

  const handleEditCancel = () => {
    setPendingEditDoor(null)
    setShowEditConfirm(false)
  }

  const handleDeleteClick = (door: (typeof doors)[0]) => {
    setDeletingDoor(door)
    setShowDeleteConfirm(true)
  }

  const handleDeleteConfirm = () => {
    if (deletingDoor) {
      deleteDoor(deletingDoor.id)
      setShowDeleteConfirm(false)
      setDeletingDoor(null)
    }
  }

  const handleDeleteCancel = () => {
    setShowDeleteConfirm(false)
    setDeletingDoor(null)
  }

  const [searchTerm, setSearchTerm] = useState("")

  const filteredDoorsByCompany = currentCompanyId
    ? doors.filter((door) => {
        const company = getCompanyById(currentCompanyId)
        return company && door.empresa_rut === company.rut
      })
    : doors

  const finalDoors = filteredDoorsByCompany.filter((d) => d.name.toLowerCase().includes(searchTerm.toLowerCase()))

  // Determinar el mensaje para el estado vacío
  const getEmptyStateMessage = () => {
    if (currentCompanyId) {
      const company = getCompanyById(currentCompanyId)
      return `No hay puertas registradas para ${company?.name || "esta empresa"}.`
    }
    return "No hay puertas registradas en el sistema."
  }

  return (
    <>
      <Header />
      <Breadcrumb />
      <div className="content-container">
        <div className="add-company-container">
          <button className="add-company-button" onClick={openAddForm}>
            Agregar Puerta
          </button>
        </div>

        <SearchBar placeholder="Buscar puertas..." value={searchTerm} onChange={setSearchTerm} />

        {finalDoors.length > 0 ? (
          <div className="door-grid">
            {finalDoors.map((door) => (
              <DoorCard key={door.id} door={door} onEdit={handleEditClick} onDelete={handleDeleteClick} />
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <DoorOpen size={48} className="empty-state-icon" />
            <h3>No hay puertas</h3>
            <p>{getEmptyStateMessage()}</p>
            <p>Haga clic en "Agregar Puerta" para registrar una nueva puerta.</p>
          </div>
        )}
      </div>

      {showAddForm && <DoorForm onClose={closeAddForm} onSubmit={handleAddDoor} title="Agregar Puerta" />}

      {showEditConfirm && (
        <ConfirmDialog
          isOpen={true}
          title="Editar Puerta"
          message={`¿Está seguro que desea editar la puerta ${pendingEditDoor?.name}?`}
          confirmText="Editar"
          onConfirm={handleEditConfirm}
          onCancel={handleEditCancel}
          type="edit"
        />
      )}

      {editingDoor && (
        <DoorForm
          door={editingDoor}
          onClose={() => setEditingDoor(null)}
          onSubmit={handleEditDoor}
          title="Editar Puerta"
        />
      )}

      <ConfirmDialog
        isOpen={showDeleteConfirm}
        title="Eliminar Puerta"
        message={`¿Está seguro que desea eliminar la puerta ${deletingDoor?.name}?`}
        confirmText="Eliminar"
        onConfirm={handleDeleteConfirm}
        onCancel={handleDeleteCancel}
        type="delete"
      />
    </>
  )
}
