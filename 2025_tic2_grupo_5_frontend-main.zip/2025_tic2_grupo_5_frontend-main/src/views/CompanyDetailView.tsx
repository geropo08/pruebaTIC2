"use client"

import { useParams, Link } from "react-router-dom"
import { Header } from "../components/Header"
import { Breadcrumb } from "../components/Breadcrumb"
import { useApp } from "../contexts/AppContext"
import { DoorOpen, Users, BarChart2 } from "lucide-react"
import { useEffect } from "react"

export function CompanyDetailView() {
  const { id } = useParams<{ id: string }>()
  const companyId = Number.parseInt(id || "0")
  const { getCompanyById, setCurrentCompanyId } = useApp()
  const company = getCompanyById(companyId)

  // Establecer la empresa actual cuando se carga la vista de detalle
  useEffect(() => {
    if (companyId) {
      setCurrentCompanyId(companyId)
    }
  }, [companyId, setCurrentCompanyId])

  if (!company) {
    return (
      <>
        <Header />
        <Breadcrumb />
        <div className="content-container">
          <div className="not-found">
            <h2>Empresa no encontrada</h2>
            <Link to="/empresas" className="back-link">
              Volver a Empresas
            </Link>
          </div>
        </div>
      </>
    )
  }

  return (
    <>
      <Header />
      <Breadcrumb />
      <div className="content-container">
        <div className="company-detail-header">
          <h2>{company.name}</h2>
          <p>RUT: {company.rut}</p>
        </div>

        <div className="menu-grid">
          <Link to="/personas" className="menu-card">
            <div className="menu-icon">
              <Users size={48} />
            </div>
            <h3>Personas</h3>
          </Link>

          <Link to="/puertas" className="menu-card">
            <div className="menu-icon">
              <DoorOpen size={48} />
            </div>
            <h3>Puertas</h3>
          </Link>

          <div className="menu-card">
            <div className="menu-icon">
              <BarChart2 size={48} />
            </div>
            <h3>Métricas</h3>
          </div>
        </div>
      </div>
    </>
  )
}
