"use client"

import { useState, useEffect } from "react"
import { Header } from "../components/Header"
import { PersonCard } from "../components/PersonCard"
import { PersonForm } from "../components/PersonForm"
import { ConfirmDialog } from "../components/ConfirmDialog"
import { useApp } from "../contexts/AppContext"
import { useModal } from "../hooks/useModal"
import { Breadcrumb } from "../components/Breadcrumb"
import { Users } from "lucide-react"
import { SearchBar } from "../components/SearchBar"
import {Person} from "../contexts/AppContext"

export function PersonView() {
  const { persons, addPerson, updatePerson, deletePerson, currentCompanyId, getCompanyById } = useApp()
  const { isOpen: showAddForm, openModal: openAddForm, closeModal: closeAddForm } = useModal()
  const [editingPerson, setEditingPerson] = useState<(typeof persons)[0] | null>(null)
  const [pendingEditPerson, setPendingEditPerson] = useState<(typeof persons)[0] | null>(null)
  const [deletingPerson, setDeletingPerson] = useState<(typeof persons)[0] | null>(null)
  const [showEditConfirm, setShowEditConfirm] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [filteredPersons, setFilteredPersons] = useState(persons)

  // Filtrar personas por empresa si hay una empresa seleccionada
  useEffect(() => {
    if (currentCompanyId) {
      const company = getCompanyById(currentCompanyId)
      if (company) {
        setFilteredPersons(persons.filter((person) => person.empresa_rut === company.rut))
      }
    } else {
      setFilteredPersons(persons)
    }
  }, [currentCompanyId, persons, getCompanyById])

  const handleAddPerson = (person: Omit<(typeof persons)[0], "id">) => {
    addPerson(person)
    closeAddForm()
  }

  const handleEditClick = (person: (typeof persons)[0]) => {
    setEditingPerson(person)
  }

  const handleEditPerson = (updatedPerson: Person | Omit<Person, "id">) => {
    setEditingPerson(null)
    if ("id" in updatedPerson) {
      setPendingEditPerson(updatedPerson)
      setShowEditConfirm(true)
    }
  }
  

  const handleEditConfirm = () => {
    if (pendingEditPerson) {
      updatePerson(pendingEditPerson)
      setPendingEditPerson(null)
    }
    setShowEditConfirm(false)
  }

  const handleEditCancel = () => {
    setPendingEditPerson(null)
    setShowEditConfirm(false)
  }

  const handleDeleteClick = (person: (typeof persons)[0]) => {
    setDeletingPerson(person)
    setShowDeleteConfirm(true)
  }

  const handleDeleteConfirm = () => {
    if (deletingPerson) {
      deletePerson(deletingPerson.id)
      setShowDeleteConfirm(false)
      setDeletingPerson(null)
    }
  }

  const handleDeleteCancel = () => {
    setShowDeleteConfirm(false)
    setDeletingPerson(null)
  }

  // Determinar el mensaje para el estado vacío
  const getEmptyStateMessage = () => {
    if (currentCompanyId) {
      const company = getCompanyById(currentCompanyId)
      return `No hay personas registradas para ${company?.name || "esta empresa"}.`
    }
    return "No hay personas registradas en el sistema."
  }

  const [searchTerm, setSearchTerm] = useState("")

  const filteredPersonsByCompany = currentCompanyId
    ? persons.filter((person) => {
        const company = getCompanyById(currentCompanyId)
        return company && person.empresa_rut === company.rut
      })
    : persons

  const finalPersons = filteredPersonsByCompany.filter((p) =>
    `${p.nombre} ${p.apellido}`.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <>
      <Header />
      <Breadcrumb />
      <div className="content-container">
        <div className="add-company-container">
          <button className="add-company-button" onClick={openAddForm}>
            Agregar Persona
          </button>
        </div>

        <SearchBar placeholder="Buscar personas..." value={searchTerm} onChange={setSearchTerm} />

        {filteredPersons.length > 0 ? (
          <div className="person-grid">
            {finalPersons.map((person) => (
              <PersonCard key={person.id} person={person} onEdit={handleEditClick} onDelete={handleDeleteClick} />
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <Users size={48} className="empty-state-icon" />
            <h3>No hay personas</h3>
            <p>{getEmptyStateMessage()}</p>
            <p>Haga clic en "Agregar Persona" para registrar una nueva persona.</p>
          </div>
        )}
      </div>

      {showAddForm && <PersonForm onClose={closeAddForm} onSubmit={handleAddPerson} title="Agregar Persona" />}

      {showEditConfirm && (
        <ConfirmDialog
          isOpen={true}
          title="Editar Persona"
          message={`¿Está seguro que desea editar a ${pendingEditPerson?.nombre} ${pendingEditPerson?.apellido}?`}
          confirmText="Editar"
          onConfirm={handleEditConfirm}
          onCancel={handleEditCancel}
          type="edit"
        />
      )}

      {editingPerson && (
        <PersonForm
          person={editingPerson}
          onClose={() => setEditingPerson(null)}
          onSubmit={handleEditPerson}
          title="Editar Persona"
        />
      )}

      <ConfirmDialog
        isOpen={showDeleteConfirm}
        title="Eliminar Persona"
        message={`¿Está seguro que desea eliminar a ${deletingPerson?.nombre} ${deletingPerson?.apellido}?`}
        confirmText="Eliminar"
        onConfirm={handleDeleteConfirm}
        onCancel={handleDeleteCancel}
        type="delete"
      />
    </>
  )
}
