"use client"

import type React from "react"

import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { User, Lock } from "lucide-react"
import { useAuth } from "../contexts/AuthContext"
import "../styles/Login.css"

export function LoginView() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const navigate = useNavigate()
  const { login } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Simple validation
    if (!username || !password) {
      setError("Por favor ingrese usuario y contraseña")
      return
    }

    const success = await login(username, password)

    if (success) {
      navigate("/empresas")
    } else {
      setError("Usuario o contraseña incorrectos")
    }
  }

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-logo">
        <img src="/images/login-icon.png" alt="Logo" className="login-icon" />
        </div>

        <h2 className="login-title">Inicio de Sesion</h2>

        {error && <div className="login-error">{error}</div>}

        <form onSubmit={handleSubmit} className="login-form">
          <div className="login-input-group">
            <User size={20} className="login-input-icon" />
            <input
              type="text"
              placeholder="Usuario"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="login-input"
            />
          </div>

          <div className="login-input-group">
            <Lock size={20} className="login-input-icon" />
            <input
              type="password"
              placeholder="Contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="login-input"
            />
          </div>

          <button type="submit" className="login-button">
            Iniciar Sesion
          </button>
        </form>
      </div>
    </div>
  )
}
