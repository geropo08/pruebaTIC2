"use client"

import { useState } from "react"
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import { Sidebar } from "./components/SideBar"
import { CompanyView } from "./views/CompanyView"
import { CompanyDetailView } from "./views/CompanyDetailView"
import { PersonView } from "./views/PersonView"
import { PersonDetail } from "./components/PersonDetail"
import { DoorView } from "./views/DoorView"
import { DoorDetail } from "./components/DoorDetail"
import { LoginView } from "./views/LoginView"
import { PasswordChangeView } from "./views/PasswordChangeView"
import { AppProvider } from "./contexts/AppContext"
import { AuthProvider } from "./contexts/AuthContext"
import "./App.css"


export interface Company {
  id: number
  name: string
  rut: string
}

function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed)
  }

  return (
    <AuthProvider>
      <AppProvider>
        <Router>
          <Routes>
            <Route path="/login" element={<LoginView />} />
            <Route
              path="/*"
              element={
                <div className="dashboard">
                  <Sidebar collapsed={sidebarCollapsed} toggleSidebar={toggleSidebar} />
                  <main className="main-content">
                    <Routes>
                      <Route path="/" element={<Navigate to="/empresas" replace />} />
                      <Route path="/empresas" element={<CompanyView />} />
                      <Route path="/empresas/:id" element={<CompanyDetailView />} />
                      <Route path="/personas" element={<PersonView />} />
                      <Route path="/personas/:id" element={<PersonDetail />} />
                      <Route path="/puertas" element={<DoorView />} />
                      <Route path="/puertas/:id" element={<DoorDetail />} />
                      <Route path="/cambio-contrasena" element={<PasswordChangeView />} />
                    </Routes>
                  </main>
                </div>
              }
            />
          </Routes>
        </Router>
      </AppProvider>
    </AuthProvider>
  )
}

export default App
